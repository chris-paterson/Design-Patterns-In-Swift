//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)
